<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SmartWorklist</name>
   <tag></tag>
   <elementGuidId>3c4dd47c-ddd2-400e-a71c-2b33fbefe4eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[contains(@test,&quot;all-extend-Component&quot;) and text()=&quot;Smart Worklist&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>//*[contains(@test,&quot;all-extend-Component&quot;) and text()=&quot;Smart Worklist&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
