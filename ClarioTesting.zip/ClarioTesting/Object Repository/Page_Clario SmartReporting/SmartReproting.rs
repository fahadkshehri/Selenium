<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SmartReproting</name>
   <tag></tag>
   <elementGuidId>aa98fc7d-6d9c-4b46-a8af-2a46c7103d12</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[contains(@test,&quot;all-extend-Component&quot;) and text()=&quot;Smart Reporting&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
